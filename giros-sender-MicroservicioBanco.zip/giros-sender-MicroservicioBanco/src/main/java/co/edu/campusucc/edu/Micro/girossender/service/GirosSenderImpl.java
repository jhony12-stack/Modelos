package co.edu.campusucc.edu.Micro.girossender.service;

import org.springframework.stereotype.Component;

import co.edu.campusucc.sd.modelos.Banco;
import co.edu.campusucc.sd.modelos.BancoHome;

@Component
public class GirosSenderImpl implements GirosSender {

	@Override
	public String CrearBanco(String idBanco, String nombre, String sede, String numeroCuenta, String idComision,
			String idPais) {

		BancoHome Dao = new BancoHome();
		
		
		try {
			//Dao.persist(idBanco, nombre, sede, numeroCuenta, idComision, idPais);
			Dao.persist(new Banco(idBanco, nombre, sede, numeroCuenta, idComision, idPais, null, null));
			System.out.println("ok");
		} catch (Exception e) {

			System.out.println(e.toString()); // TODO
		}

		return "ok";
	}

}
