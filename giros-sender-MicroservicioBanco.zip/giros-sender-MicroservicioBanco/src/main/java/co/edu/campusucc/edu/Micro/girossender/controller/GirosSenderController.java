package co.edu.campusucc.edu.Micro.girossender.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import co.edu.campusucc.edu.Micro.girossender.service.GirosSender;


@RestController
public class GirosSenderController {

	@Autowired
	private GirosSender girosSender;

	@GetMapping("/crearbanco/idbanco/{idBanco}/nombredelbanco/{nombre}/nombresede/{sede}/numeroCuenta/{numeroCuenta}/idcomision/{idComision}/idbanco/{idBanco}/idpais/{idPais}")
	public String CrearBanco(@PathVariable String idBanco,@PathVariable String nombre, @PathVariable String sede,@PathVariable String numeroCuenta,@PathVariable String idComision,
			@PathVariable String idPais) {

		return girosSender.CrearBanco(idBanco, nombre ,sede, numeroCuenta, idComision, idPais);
	}
}