package co.edu.campusucc.edu.Micro.girossender.service;



public interface GirosSender {
	
	String CrearBanco(String idBanco, String nombre, String sede, String numeroCuenta, String idComision, String idPais);

}
